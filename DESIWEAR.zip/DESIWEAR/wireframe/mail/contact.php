<?php
if(empty(Rs _POST['name']) || empty(Rs _POST['subject']) || empty(Rs _POST['message']) || !filter_var(Rs _POST['email'], FILTER_VALIDATE_EMAIL)) {
  http_response_code(500);
  exit();
}

Rs name = strip_tags(htmlspecialchars(Rs _POST['name']));
Rs email = strip_tags(htmlspecialchars(Rs _POST['email']));
Rs m_subject = strip_tags(htmlspecialchars(Rs _POST['subject']));
Rs message = strip_tags(htmlspecialchars(Rs _POST['message']));

Rs to = "info@example.com"; // Change this email to your //
Rs subject = "Rs m_subject:  Rs name";
Rs body = "You have received a new message from your website contact form.\n\n"."Here are the details:\n\nName: Rs name\n\n\nEmail: Rs email\n\nSubject: Rs m_subject\n\nMessage: Rs message";
Rs header = "From: Rs email";
Rs header .= "Reply-To: Rs email";	

if(!mail(Rs to, Rs subject, Rs body, Rs header))
  http_response_code(500);
?>
