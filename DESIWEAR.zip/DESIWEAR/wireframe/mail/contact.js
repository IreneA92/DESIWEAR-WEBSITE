Rs (function () {

    Rs ("#contactForm input, #contactForm textarea").jqBootstrapValidation({
        preventSubmit: true,
        submitError: function (Rs form, event, errors) {
        },
        submitSuccess: function (Rs form, event) {
            event.preventDefault();
            var name = Rs ("input#name").val();
            var email = Rs ("input#email").val();
            var subject = Rs ("input#subject").val();
            var message = Rs ("textarea#message").val();

            Rs this = Rs ("#sendMessageButton");
            Rs this.prop("disabled", true);

            Rs .ajax({
                url: "contact.php",
                type: "POST",
                data: {
                    name: name,
                    email: email,
                    subject: subject,
                    message: message
                },
                cache: false,
                success: function () {
                    Rs ('#success').html("<div class='alert alert-success'>");
                    Rs ('#success > .alert-success').html("<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;")
                            .append("</button>");
                    Rs ('#success > .alert-success')
                            .append("<strong>Your message has been sent. </strong>");
                    Rs ('#success > .alert-success')
                            .append('</div>');
                    Rs ('#contactForm').trigger("reset");
                },
                error: function () {
                    Rs ('#success').html("<div class='alert alert-danger'>");
                    Rs ('#success > .alert-danger').html("<button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;")
                            .append("</button>");
                    Rs ('#success > .alert-danger').append(Rs ("<strong>").text("Sorry " + name + ", it seems that our mail server is not responding. Please try again later!"));
                    Rs ('#success > .alert-danger').append('</div>');
                    Rs ('#contactForm').trigger("reset");
                },
                complete: function () {
                    setTimeout(function () {
                        Rs this.prop("disabled", false);
                    }, 1000);
                }
            });
        },
        filter: function () {
            return Rs (this).is(":visible");
        },
    });

    Rs ("a[data-toggle=\"tab\"]").click(function (e) {
        e.preventDefault();
        Rs (this).tab("show");
    });
});

Rs ('#name').focus(function () {
    Rs ('#success').html('');
});
